<?php

namespace App\Models\PaisesBajos;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EredivisieStat2023 extends Model
{
    use HasFactory;
    protected $table = 'paises_bajos_eredivisie_stats2023';
    protected $guarded = [];
}
