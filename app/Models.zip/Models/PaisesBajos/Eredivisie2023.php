<?php

namespace App\Models\PaisesBajos;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Eredivisie2023 extends Model
{
    use HasFactory;
    protected $table = 'paises_bajos_eredivisie_fixtures2023';
    protected $guarded = [];
}
