<?php

namespace App\Models\PaisesBajos;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CopaPaisesBajosStat extends Model
{
    use HasFactory;
    protected $table = 'paises_bajos_copa_paises_bajos_stats2023';
    protected $guarded = [];
}
