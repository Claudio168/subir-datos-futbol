<?php

namespace App\Models\Espana;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FixtureLaLigaStat extends Model
{
    use HasFactory;
    protected $table = 'espania_la_liga_stats2023';
    protected $guarded = [];
}
