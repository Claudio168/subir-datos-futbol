<?php

namespace App\Models\Espana;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CopaRey2023 extends Model
{
    use HasFactory;
    protected $table = 'espania_copa_rey2023';
    protected $guarded = [];
}
