<?php

namespace App\Models\Espana;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SubirLaLigaFixture2023 extends Model
{
    use HasFactory;
    protected $table = 'espania_la_liga_fixtures2023';
    protected $guarded = [];
}
