<?php

namespace App\Models\Colombia;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ColombiaAperturaStat2024 extends Model
{
    use HasFactory;
    protected $table = 'colombia_apertura_stats2024';
    protected $guarded = [];
}
