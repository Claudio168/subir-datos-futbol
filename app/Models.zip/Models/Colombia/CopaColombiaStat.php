<?php

namespace App\Models\Colombia;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CopaColombiaStat extends Model
{
    use HasFactory;
    protected $table = 'colombia_copa_colombia_stats2024';
    protected $guarded = [];
}
