<?php

namespace App\Models\Colombia;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ColombiaApertura2024 extends Model
{
    use HasFactory;
    protected $table = 'colombia_apertura2024';
    protected $guarded = [];
}
