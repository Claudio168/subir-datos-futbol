<?php

namespace App\Models\Inglaterra;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CopaLiga extends Model
{
    use HasFactory;
    protected $table = 'inglaterra_copa_de_la_liga2023';
    protected $guarded = [];

}
