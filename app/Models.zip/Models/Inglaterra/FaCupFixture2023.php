<?php

namespace App\Models\Inglaterra;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FaCupFixture2023 extends Model
{
    use HasFactory;
    protected $table = 'inglaterra_fa_cup2023';
    protected $guarded = [];

}
