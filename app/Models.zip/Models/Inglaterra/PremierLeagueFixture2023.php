<?php

namespace App\Models\Inglaterra;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PremierLeagueFixture2023 extends Model
{
    use HasFactory;
    protected $table = 'inglaterra_premierleaguefixtures2023';
    protected $guarded = [];

}
