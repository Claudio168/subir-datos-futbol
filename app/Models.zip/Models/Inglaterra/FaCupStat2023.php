<?php

namespace App\Models\Inglaterra;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FaCupStat2023 extends Model
{

    use HasFactory;
    protected $table = 'inglaterra_fa_cup_stats2023';
    protected $guarded = [];


   
}
