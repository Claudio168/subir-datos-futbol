<?php

namespace App\Models\Inglaterra;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CopaLigaStat extends Model
{
    use HasFactory;
    protected $table = 'inglaterra_copa_de_la_liga_stats2023';
    protected $guarded = [];

}
