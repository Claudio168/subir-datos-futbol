<?php

namespace App\Models\Inglaterra;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PremierLeagueStat2023 extends Model
{

    use HasFactory;
    protected $table = 'inglaterra_premier_league_stats2023';
    protected $guarded = [];


   
}
