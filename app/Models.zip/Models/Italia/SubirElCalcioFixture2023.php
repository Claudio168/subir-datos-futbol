<?php

namespace App\Models\Italia;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SubirElCalcioFixture2023 extends Model
{
    use HasFactory;
    protected $table = 'italia_el_calcio_fixtures2023';
    protected $guarded = [];

}
