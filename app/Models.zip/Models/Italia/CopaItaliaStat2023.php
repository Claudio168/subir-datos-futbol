<?php

namespace App\Models\Italia;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CopaItaliaStat2023 extends Model
{
    use HasFactory;
    protected $table = 'italia_copa_italia_stats2023';
    protected $guarded = [];
}
