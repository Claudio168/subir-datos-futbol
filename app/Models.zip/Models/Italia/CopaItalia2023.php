<?php

namespace App\Models\Italia;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CopaItalia2023 extends Model
{
    use HasFactory;
    protected $table = 'italia_copa_italia2023';
    protected $guarded = [];
}
