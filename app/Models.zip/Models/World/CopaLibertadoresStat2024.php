<?php

namespace App\Models\World;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CopaLibertadoresStat2024 extends Model
{
    use HasFactory;
    protected $table = 'world_copa_libertadores_stats2024';
    protected $guarded = [];
}
