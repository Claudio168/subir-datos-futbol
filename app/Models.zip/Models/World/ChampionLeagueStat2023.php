<?php

namespace App\Models\World;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ChampionLeagueStat2023 extends Model
{

    use HasFactory;
    protected $table = 'world_championleaguestats2023';
    protected $guarded = [];


   
}