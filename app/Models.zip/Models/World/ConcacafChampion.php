<?php

namespace App\Models\World;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ConcacafChampion extends Model
{

    use HasFactory;
    protected $table = 'world_concacaf_champions_league2024';
    protected $guarded = [];


   
}
