<?php

namespace App\Models\World;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EuropaLeagueStat2023 extends Model
{

    use HasFactory;
    protected $table = 'world_europa_league_stats2023';
    protected $guarded = [];


   
}