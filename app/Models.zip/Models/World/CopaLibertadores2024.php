<?php

namespace App\Models\World;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CopaLibertadores2024 extends Model
{
    use HasFactory;
    protected $table = 'world_copa_libertadores_2024';
    protected $guarded = [];
}
