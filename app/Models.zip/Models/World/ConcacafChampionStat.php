<?php

namespace App\Models\World;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ConcacafChampionStat extends Model
{

    use HasFactory;
    protected $table = 'world_concacaf_champions_league_stats2024';
    protected $guarded = [];


   
}
