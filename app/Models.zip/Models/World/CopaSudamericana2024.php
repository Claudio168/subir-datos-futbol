<?php

namespace App\Models\World;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CopaSudamericana2024 extends Model
{
    use HasFactory;
    protected $table = 'world_copa_sudamericana_2024';
    protected $guarded = [];
}
