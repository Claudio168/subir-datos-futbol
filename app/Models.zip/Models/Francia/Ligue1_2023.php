<?php

namespace App\Models\Francia;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ligue1_2023 extends Model
{
    use HasFactory;
    protected $table = 'francia_ligue1_2023';
    protected $guarded = [];

}