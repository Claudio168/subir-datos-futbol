<?php

namespace App\Models\Francia;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CopaFranciaStat extends Model
{
    use HasFactory;
    protected $table = 'francia_copa_francia_stats2023';
    protected $guarded = [];

}