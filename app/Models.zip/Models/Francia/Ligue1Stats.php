<?php

namespace App\Models\Francia;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ligue1Stats extends Model
{
    use HasFactory;
    protected $table = 'francia_ligue1_stats2023';
    protected $guarded = [];
}
