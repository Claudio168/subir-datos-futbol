<?php

namespace App\Models\Francia;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CopaFrancia extends Model
{
    use HasFactory;
    protected $table = 'francia_copa_francia2023';
    protected $guarded = [];

}