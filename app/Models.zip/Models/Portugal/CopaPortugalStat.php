<?php

namespace App\Models\Portugal;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CopaPortugalStat extends Model
{
    use HasFactory;
    protected $table = 'portugal_copa_portugal_stats2023';
    protected $guarded = [];
}
