<?php

namespace App\Models\Portugal;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PrimeiraLigaStat2023 extends Model
{
    use HasFactory;
    protected $table = 'portugal_primeira_liga_stats2023';
    protected $guarded = [];

}