<?php

namespace App\Models\Portugal;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Primeira_liga2023 extends Model
{
    use HasFactory;
    protected $table = 'portugal_primeira_liga2023';
    protected $guarded = [];

}