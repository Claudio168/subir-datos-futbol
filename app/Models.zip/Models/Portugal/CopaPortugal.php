<?php

namespace App\Models\Portugal;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CopaPortugal extends Model
{
    use HasFactory;
    protected $table = 'portugal_copa_portugal2023';
    protected $guarded = [];
}
