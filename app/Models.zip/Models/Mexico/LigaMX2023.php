<?php

namespace App\Models\Mexico;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LigaMX2023 extends Model
{
    use HasFactory;
    protected $table = 'mexico_liga_mx_2023';
    protected $guarded = [];
}
