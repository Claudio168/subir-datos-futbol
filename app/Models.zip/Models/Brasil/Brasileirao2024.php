<?php

namespace App\Models\Brasil;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Brasileirao2024 extends Model
{
    use HasFactory;

    protected $table = 'brasil_brasileirao_serie_a_2024';
    protected $guarded = [];
}


