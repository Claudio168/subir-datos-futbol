<?php

namespace App\Models\Argentina;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CopaDeLaLigaStat extends Model
{
    use HasFactory;
    protected $table = 'argentina_copa_de_la_liga_argentina_stats2024';
    protected $guarded = [];
}
