<?php

namespace App\Models\Argentina;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CopaDeLaLiga extends Model
{
    use HasFactory;
    protected $table = 'argentina_copa_de_la_liga_argentina2024';
    protected $guarded = [];
}
