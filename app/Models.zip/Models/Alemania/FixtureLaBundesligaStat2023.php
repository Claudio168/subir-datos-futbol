<?php

namespace App\Models\Alemania;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FixtureLaBundesligaStat2023 extends Model
{
    use HasFactory;
    protected $table = 'alemania_la_bundesliga_stats2023';
    protected $guarded = [];
}
