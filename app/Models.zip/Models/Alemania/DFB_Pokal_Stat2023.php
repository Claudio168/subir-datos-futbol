<?php

namespace App\Models\Alemania;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DFB_Pokal_Stat2023 extends Model
{
    use HasFactory;
    protected $table = 'alemania_dfb_pokal_stats2023';
    protected $guarded = [];
}
