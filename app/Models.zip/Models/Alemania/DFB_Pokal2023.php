<?php

namespace App\Models\Alemania;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DFB_Pokal2023 extends Model
{
    use HasFactory;
    protected $table = 'alemania_dfb_pokal2023';
    protected $guarded = [];

}
