<?php

namespace App\Models\Alemania;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SubirLaBundesligaFixture2023 extends Model
{
    use HasFactory;
    protected $table = 'alemania_la_bundesliga_fixtures2023';
    protected $guarded = [];
}
