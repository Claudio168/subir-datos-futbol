<?php

namespace App\Models\Chile;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PrimeraDivisionStat2024 extends Model
{
    use HasFactory;
    protected $table = 'chile_primera_divisionstats2024';
    protected $guarded = [];
}
