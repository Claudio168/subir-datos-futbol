<?php

namespace App\Models\Chile;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Chile_primera_division2024 extends Model
{
    use HasFactory;
    protected $table = 'chile_primera_division2024';
    protected $guarded = [];
}
