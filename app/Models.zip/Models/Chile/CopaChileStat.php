<?php

namespace App\Models\Chile;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CopaChileStat extends Model
{
    use HasFactory;
    protected $table = 'chile_copa_chile_stats2024';
    protected $guarded = [];
}
