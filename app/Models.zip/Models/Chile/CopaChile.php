<?php

namespace App\Models\Chile;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CopaChile extends Model
{
    use HasFactory;
    protected $table = 'chile_copa_chile2023';
    protected $guarded = [];
}
